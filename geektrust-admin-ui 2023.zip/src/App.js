import React, { useState, useEffect } from "react";
import "./styles.css";
import UserTable from "./components/UserTable";
import SearchBar from "./components/SearchBar";
import DeleteSelectedButton from "./components/DeleteSelectedButton";

function App() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null); // New state for editing
  const usersPerPage = 10;

  useEffect(() => {
    async function fetchUsers() {
      try {
        const response = await fetch(
          "https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json"
        );
        const data = await response.json();
        // Adding isEditing property to each user
        const usersWithEdit = data.map((user) => ({
          ...user,
          isEditing: editingUser && editingUser.id === user.id
        }));
        setUsers(usersWithEdit);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    }

    fetchUsers();
  }, [editingUser]);

  function handleEdit(user) {
    setEditingUser(user);
  }

  function handleDelete(user) {
    setUsers(users.filter((u) => u.id !== user.id));
    setSelectedUsers(selectedUsers.filter((u) => u.id !== user.id));
  }

  function handleSelectAll() {
    if (selectedUsers.length === users.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(users);
    }
  }

  function handleSelect(user) {
    setSelectedUsers((prevSelected) =>
      prevSelected.some((u) => u.id === user.id)
        ? prevSelected.filter((u) => u.id !== user.id)
        : [...prevSelected, user]
    );
  }

  function handleDeleteSelected() {
    setUsers(users.filter((user) => !selectedUsers.includes(user)));
    setSelectedUsers([]);
  }

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <main className="app">
      <SearchBar
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <UserTable
        users={users}
        selectedUsers={selectedUsers}
        currentPage={currentPage}
        usersPerPage={usersPerPage}
        totalUsers={users.length}
        onSelectAll={handleSelectAll}
        onSelect={handleSelect}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onPageChange={setCurrentPage}
        onDeleteSelected={handleDeleteSelected}
        searchQuery={searchQuery}
      />
    </main>
  );
}

export default App;
