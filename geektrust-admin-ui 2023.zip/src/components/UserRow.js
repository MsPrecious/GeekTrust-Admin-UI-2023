import React, { useState } from "react";

function UserRow({ user, onEdit, onDelete, isSelected, onSelect }) {
  const [editedName, setEditedName] = useState(user.name);
  const [editedEmail, setEditedEmail] = useState(user.email);
  const [editedRole, setEditedRole] = useState(user.role);

  const isEditing = user.isEditing;
  const handleSaveEdit = () => {
    onEdit({
      id: user.id,
      name: editedName,
      email: editedEmail,
      role: editedRole,
      isEditing: false
    });
  };

  return (
    <tr key={user.id} className={isSelected ? "selected" : ""}>
      <td>
        <input
          type="checkbox"
          checked={isSelected}
          onChange={() => onSelect(user)}
        />
      </td>
      <td>
        {isEditing ? (
          <input
            type="text"
            value={editedName}
            onChange={(e) => setEditedName(e.target.value)}
          />
        ) : (
          user.name
        )}
      </td>
      <td>
        {isEditing ? (
          <input
            type="text"
            value={editedEmail}
            onChange={(e) => setEditedEmail(e.target.value)}
          />
        ) : (
          user.email
        )}
      </td>
      <td>
        {isEditing ? (
          <input
            type="text"
            value={editedRole}
            onChange={(e) => setEditedRole(e.target.value)}
          />
        ) : (
          user.role
        )}
      </td>
      <td>
        {isEditing ? (
          <span role="button" onClick={handleSaveEdit} aria-label="Save">
            Save
          </span>
        ) : (
          <span
            role="button"
            aria-label="Edit"
            className="action-icon"
            onClick={() => onEdit(user)}
          >
            ✏️
          </span>
        )}
        <span
          role="button"
          aria-label="Delete"
          className="action-icon red"
          onClick={() => onDelete(user)}
        >
          🗑️
        </span>
      </td>
    </tr>
  );
}

export default UserRow;
