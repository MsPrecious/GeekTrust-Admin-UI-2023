import React from "react";

function DeleteSelectedButton({ onClick, disabled }) {
  return (
    <div className="delete-selected-button">
      <button onClick={onClick} disabled={disabled}>
        Delete Selected
      </button>
    </div>
  );
}

export default DeleteSelectedButton;
