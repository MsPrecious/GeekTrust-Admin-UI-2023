import React from "react";
import UserRow from "./UserRow";

function UserTable({
  users,
  selectedUsers,
  currentPage,
  usersPerPage,
  totalUsers,
  onSelectAll,
  onSelect,
  onEdit,
  onDelete,
  onPageChange,
  onDeleteSelected,
  searchQuery // Add searchQuery prop
}) {
  const startIndex = (currentPage - 1) * usersPerPage;
  const endIndex = startIndex + usersPerPage;

  // Apply the search filter to the users array
  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const pageUsers = filteredUsers.slice(startIndex, endIndex);
  const totalPages = Math.ceil(filteredUsers.length / usersPerPage);

  const renderPaginationButtons = () => {
    const paginationButtons = [];
    if (totalPages <= 1) {
      return null; // Don't show pagination if there's only one page
    }

    // Previous button
    paginationButtons.push(
      <button
        key="<<"
        className="pagination-button circular blue"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
      >
        &lt;&lt;
      </button>
    );

    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
      paginationButtons.push(
        <button
          key={i}
          className={`pagination-button circular ${
            currentPage === i ? "active" : "blue"
          }`}
          onClick={() => onPageChange(i)}
        >
          {i}
        </button>
      );
    }

    // Next button
    paginationButtons.push(
      <button
        key=">>"
        className="pagination-button circular blue"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
      >
        &gt;&gt;
      </button>
    );

    return <div className="pagination">{paginationButtons}</div>;
  };

  const renderedPaginationButtons = renderPaginationButtons();

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>
              <input
                type="checkbox"
                checked={selectedUsers.length === pageUsers.length}
                onChange={onSelectAll}
              />
            </th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {pageUsers.map((user) => (
            <UserRow
              key={user.id}
              user={user}
              onEdit={onEdit}
              onDelete={onDelete}
              isSelected={selectedUsers.some((u) => u.id === user.id)}
              onSelect={onSelect}
            />
          ))}
        </tbody>
      </table>
      <div className="pagination-delete-container">
        <div className="delete-selected">
          <button
            onClick={onDeleteSelected}
            disabled={selectedUsers.length === 0}
          >
            Delete Selected
          </button>
        </div>
        <div className="pagination">{renderedPaginationButtons}</div>
      </div>
    </div>
  );
}

export default UserTable;
